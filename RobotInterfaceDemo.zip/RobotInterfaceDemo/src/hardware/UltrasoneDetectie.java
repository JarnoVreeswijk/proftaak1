package hardware;

public interface UltrasoneDetectie {
	void onUltraSoneDetect(int distance);
}
