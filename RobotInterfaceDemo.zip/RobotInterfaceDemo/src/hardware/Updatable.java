package hardware;

public interface Updatable {
	void update();
}
