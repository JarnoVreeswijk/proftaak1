package hardware;

public interface AfstandsbedieningButtonPress {
	void onAfstandsbediening(int code);
}
